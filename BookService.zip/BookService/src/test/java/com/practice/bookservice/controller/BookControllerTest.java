package com.practice.bookservice.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import com.practice.bookservice.model.Book;

@RunWith(SpringRunner.class)
@SpringBootTest

public class BookControllerTest {

	@Autowired
	BookController bookController;
	
	@Test
	public void testgetBook() throws Exception {
		
		Book book1 = new Book();
		book1.setIsbn(1L);
		book1.setBookName("The Secret");
		book1.setAuthor("Rhonda Byrne");
		book1.setPageNumber(228);
		book1.setPrice(432);
		bookController.saveBook(book1);
		bookController.getBook(1L);
		
	    ResponseEntity<?> bookEntity = bookController.getBook(1L);
		Book book = (Book) bookEntity.getBody();
		assertEquals(book.getIsbn(),book1.getIsbn());
		assertEquals(book.getBookName(),book1.getBookName());
		assertEquals(book.getAuthor(),book1.getAuthor());
		assertEquals(book.getPageNumber(),book1.getPageNumber());
		assertEquals(book.getPrice(),book1.getPrice());
        try {
			
			bookController.deleteBook(book1.getIsbn());
		 }
		catch(Exception e) {
			
		}
	}
	
	@Test
	public void testgetAllBooks() throws Exception {
		
		Book book1 = new Book();
		book1.setIsbn(1L);
		book1.setBookName("The Secret");
		book1.setAuthor("Rhonda Byrne");
		book1.setPageNumber(228);
		book1.setPrice(432);
		bookController.saveBook(book1);
		
		Book book2 = new Book();
		book2.setIsbn(2L);
		book2.setBookName("MeinKamf");
		book2.setAuthor("Adolf Hitler");
		book2.setPageNumber(599);
		book2.setPrice(500);
		bookController.saveBook(book2);
				
	    ResponseEntity<?> bookEntity = bookController.getAllBooks();
	    List<Book> bookList =(List<Book>) bookEntity.getBody();
	    assertFalse(bookList.isEmpty());
        try {
			
			bookController.deleteBook(book1.getIsbn());
		 }
		catch(Exception e) {
			
		}
        try {
			
			bookController.deleteBook(book2.getIsbn());
		 }
		catch(Exception e) {
			
		}
	}
	@Test
	public void testsaveBook() throws Exception {
		
		Book book1 = new Book();
		book1.setIsbn(1L);
		book1.setBookName("The Secret");
		book1.setAuthor("Rhonda Byrne");
		book1.setPageNumber(228);
		book1.setPrice(432);
		bookController.saveBook(book1);
		ResponseEntity<?> bookEntity = bookController.getBook(1L);
		Book book = (Book) bookEntity.getBody();
		assertEquals(book.getIsbn(),book1.getIsbn());
		assertEquals(book.getBookName(),book1.getBookName());
		assertEquals(book.getAuthor(),book.getAuthor());
		assertEquals(book.getPageNumber(),book1.getPageNumber());
		assertEquals(book.getPrice(), book1.getPrice());
		 try {
			 bookController.deleteBook(book1.getIsbn());
		}
			    catch(Exception e) {
			    	
			    }
	}
	@Test
	public void testupdateBook() throws Exception {
		
		Book saveBook = new Book();
		saveBook.setIsbn(1L);
		saveBook.setBookName("The Secret");
		saveBook.setAuthor("Rhonda Byrne");
		saveBook.setPageNumber(228);
		saveBook.setPrice(432);
		bookController.saveBook(saveBook);
		saveBook.setPageNumber(528);
		bookController.saveBook(saveBook);
		ResponseEntity<?> bookEntity = bookController.getBook(1L);
		Book book = (Book) bookEntity.getBody();
		assertEquals(book.getIsbn(),saveBook.getIsbn());
		assertEquals(book.getBookName(),saveBook.getBookName());
		assertEquals(book.getAuthor(),saveBook.getAuthor());
		assertEquals(book.getPageNumber(),saveBook.getPageNumber());
		assertEquals(book.getPrice(), saveBook.getPrice());

		 try {
			 bookController.deleteBook(saveBook.getIsbn());
		}
			    catch(Exception e) {
			    	
			    }
	}
	
	@Test
	public void testdeleteBook() throws Exception {
		
		Book book1 = new Book();
		book1.setIsbn(1L);
		book1.setBookName("The Secret");
		book1.setAuthor("Rhonda Byrne");
		book1.setPageNumber(228);
		book1.setPrice(432);
		bookController.saveBook(book1);
		 try {
			 bookController.deleteBook(book1.getIsbn());
		}
			    catch(Exception e) {
			    	
	   }	
		
	}	

}
