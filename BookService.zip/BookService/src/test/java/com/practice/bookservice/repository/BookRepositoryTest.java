package com.practice.bookservice.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import com.practice.bookservice.model.Book;

@RunWith(SpringRunner.class)
@SpringBootTest
public class BookRepositoryTest {
	
	@Autowired
	BookRepository bookRepository;
	
	@Test
	public void testgetBook() throws Exception {
		
		Book book1 = new Book();
		book1.setIsbn(1L);
		book1.setBookName("The Secret");
		book1.setAuthor("Rhonda Byrne");
		book1.setPageNumber(228);
		book1.setPrice(432);
		bookRepository.save(book1);
		Book book =  bookRepository.findOne(1L);
		assertEquals(book.getIsbn(),book1.getIsbn());
		assertEquals(book.getBookName(),book1.getBookName());
		assertEquals(book.getAuthor(),book1.getAuthor());
		assertEquals(book.getPageNumber(),book1.getPageNumber());
		assertEquals(book.getPrice(),book1.getPrice());
        try {
        	bookRepository.delete(1L);
        	
		 }
		catch(Exception e) {
			
		}
	}
	
	@Test
	public void testgetAllBooks() throws Exception {
		
		Book book1 = new Book();
		book1.setIsbn(1L);
		book1.setBookName("The Secret");
		book1.setAuthor("Rhonda Byrne");
		book1.setPageNumber(228);
		book1.setPrice(432);
		bookRepository.save(book1);
		
		Book book2 = new Book();
		book2.setIsbn(2L);
		book2.setBookName("MeinKamf");
		book2.setAuthor("Adolf Hitler");
		book2.setPageNumber(599);
		book2.setPrice(500);
		bookRepository.save(book2);

		List<Book> bookList = bookRepository.findAll();
	    assertFalse(bookList.isEmpty());
        try {
			
        	bookRepository.delete(1L);
		 }
		catch(Exception e) {
			
		}
        try {
			
        	bookRepository.delete(2L);
		 }
		catch(Exception e) {
			
		}
	}
	@Test
	public void testsaveBook() throws Exception {
		
		Book book1 = new Book();
		book1.setIsbn(1L);
		book1.setBookName("The Secret");
		book1.setAuthor("Rhonda Byrne");
		book1.setPageNumber(228);
		book1.setPrice(432);
		bookRepository.save(book1);
		Book book = bookRepository.findOne(1L);
		assertEquals(book.getIsbn(),book1.getIsbn());
		assertEquals(book.getBookName(),book1.getBookName());
		assertEquals(book.getAuthor(),book.getAuthor());
		assertEquals(book.getPageNumber(),book1.getPageNumber());
		assertEquals(book.getPrice(), book1.getPrice());
		 try {
			 bookRepository.delete(1L);
		}
			    catch(Exception e) {
			    	
			    }
	}
	@Test
	public void testupdateBook() throws Exception {
		
		Book saveBook = new Book();
		saveBook.setIsbn(1L);
		saveBook.setBookName("The Secret");
		saveBook.setAuthor("Rhonda Byrne");
		saveBook.setPageNumber(228);
		saveBook.setPrice(432);
		bookRepository.save(saveBook);
		saveBook.setPageNumber(528);
		bookRepository.save(saveBook);
		Book book = bookRepository.findOne(1L);
		assertEquals(book.getIsbn(),saveBook.getIsbn());
		assertEquals(book.getBookName(),saveBook.getBookName());
		assertEquals(book.getAuthor(),saveBook.getAuthor());
		assertEquals(book.getPageNumber(),saveBook.getPageNumber());
		assertEquals(book.getPrice(), saveBook.getPrice());

		 try {
			 bookRepository.delete(1L);
		}
			    catch(Exception e) {
			    	
			    }
	}
	
	@Test
	public void testdeleteBook() throws Exception {
		
		Book book1 = new Book();
		book1.setIsbn(1L);
		book1.setBookName("The Secret");
		book1.setAuthor("Rhonda Byrne");
		book1.setPageNumber(228);
		book1.setPrice(432);
		bookRepository.save(book1);
		 try {
			 bookRepository.delete(1L);
		}
			    catch(Exception e) {
			    	
	   }	
		
	}	
}