package com.practice.bookservice.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import com.practice.bookservice.model.Book;

@RunWith(SpringRunner.class)
@SpringBootTest
public class BookServiceTest {

	@Autowired
	BookService bookService;
	
	@Test
	public void testgetBook() throws Exception {
		
		Book book1 = new Book();
		book1.setIsbn(1L);
		book1.setBookName("The Secret");
		book1.setAuthor("Rhonda Byrne");
		book1.setPageNumber(228);
		book1.setPrice(432);
		bookService.saveBook(book1);
		ResponseEntity<?> bookEntity = bookService.getBook(1L);
		Book book = (Book) bookEntity.getBody();
		assertEquals(book.getIsbn(),book1.getIsbn());
		assertEquals(book.getBookName(),book1.getBookName());
		assertEquals(book.getAuthor(),book.getAuthor());
		assertEquals(book.getPageNumber(),book1.getPageNumber());
		assertEquals(book.getPrice(), book1.getPrice());
		try {
			
			bookService.deleteBook(book1.getIsbn());
		 }
		catch(Exception e) {
			
		}
	}
	
	@Test
	public void testgetAllBooks() throws Exception {
		
		Book book1 = new Book();
		book1.setIsbn(1L);
		book1.setBookName("The Secret");
		book1.setAuthor("Rhonda Byrne");
		book1.setPageNumber(228);
		book1.setPrice(432);
		bookService.saveBook(book1);
		
		Book book2 = new Book();
		book2.setIsbn(2L);
		book2.setBookName("1920");
		book2.setAuthor("Chetan Bhagat");
		book2.setPageNumber(150);
		book2.setPrice(60);
		bookService.saveBook(book2);
		ResponseEntity<?> bookEntity = bookService.getAllBooks();
		List<Book> bookList =(List<Book>) bookEntity.getBody();
	    assertFalse(bookList.isEmpty());
	    try {
	    	
	    	bookService.deleteBook(book1.getIsbn());
	    }
	    catch(Exception e) {	    	
	    }
	    try {
	    	
	    	bookService.deleteBook(book1.getIsbn());
		}
		    catch(Exception e) {
		    	
		    }	    
	}
	
	@Test
	public void testsaveBook() throws Exception {
		
		Book book1 = new Book();
		book1.setIsbn(1L);
		book1.setBookName("The Secret");
		book1.setAuthor("Rhonda Byrne");
		book1.setPageNumber(228);
		book1.setPrice(432);
		bookService.saveBook(book1);
		ResponseEntity<?> bookEntity = bookService.getBook(1L);
		Book book = (Book) bookEntity.getBody();
		assertEquals(book.getIsbn(),book1.getIsbn());
		assertEquals(book.getBookName(),book1.getBookName());
		assertEquals(book.getAuthor(),book.getAuthor());
		assertEquals(book.getPageNumber(),book1.getPageNumber());
		assertEquals(book.getPrice(), book1.getPrice());
		 try {
			 bookService.deleteBook(book1.getIsbn());
		}
			    catch(Exception e) {
			    	
			    }
	}
	@Test
	public void testupdateBook() throws Exception {
		
		Book saveBook = new Book();
		saveBook.setIsbn(1L);
		saveBook.setBookName("The Secret");
		saveBook.setAuthor("Rhonda Byrne");
		saveBook.setPageNumber(228);
		saveBook.setPrice(432);
		bookService.saveBook(saveBook);
		saveBook.setPageNumber(528);
		bookService.saveBook(saveBook);
		ResponseEntity<?> bookEntity = bookService.getBook(1L);
		Book book = (Book) bookEntity.getBody();
		assertEquals(book.getIsbn(),saveBook.getIsbn());
		assertEquals(book.getBookName(),saveBook.getBookName());
		assertEquals(book.getAuthor(),saveBook.getAuthor());
		assertEquals(book.getPageNumber(),saveBook.getPageNumber());
		assertEquals(book.getPrice(), saveBook.getPrice());

		 try {
			 bookService.deleteBook(saveBook.getIsbn());
		}
			    catch(Exception e) {
			    	
			    }
	}
	
	@Test
	public void testdeleteBook() throws Exception {
		
		Book book1 = new Book();
		book1.setIsbn(1L);
		book1.setBookName("The Secret");
		book1.setAuthor("Rhonda Byrne");
		book1.setPageNumber(228);
		book1.setPrice(432);
		bookService.saveBook(book1);
		 try {
			 bookService.deleteBook(book1.getIsbn());
		}
			    catch(Exception e) {
			    	
	   }	
		
	}
	
}
