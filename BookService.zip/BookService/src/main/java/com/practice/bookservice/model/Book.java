package com.practice.bookservice.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Book implements Serializable {
	
	/**
	 * Generated serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	
	@Id
	private Long isbn;
	
	@Column(nullable=false)
	private String bookName;
	
	@Column(nullable=false)
	private String author;
	
	@Column(nullable=false)
	private int pageNumber;
	
	@Column(nullable=false)
	private int price;
	
	public Book() {
		
	}

	public Book(Long isbn, String bookName, String author, int pageNumber, int price) {
		super();
		this.isbn = isbn;
		this.bookName = bookName;
		this.author = author;
		this.pageNumber = pageNumber;
		this.price = price;
	}

	public Long getIsbn() {
		return isbn;
	}

	public void setIsbn(Long isbn) {
		this.isbn = isbn;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public int getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", bookName=" + bookName + ", author=" + author + ", pageNumber=" + pageNumber
				+ ", price=" + price + "]";
	}

	
}
