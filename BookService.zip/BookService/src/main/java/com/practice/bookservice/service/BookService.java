package com.practice.bookservice.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.practice.bookservice.model.Book;
import com.practice.bookservice.repository.BookRepository;

@Service
public class BookService {
	
	@Autowired
	public BookRepository bookRepository;
	
	public ResponseEntity<?> getBook(Long isbn) {
		Book book = bookRepository.findOne(isbn);
		ResponseEntity<?> bookResponseEntity = null;
		if( book == null) {
			bookResponseEntity = ResponseEntity.status(HttpStatus.NO_CONTENT).body(book);
			return bookResponseEntity;
		}
		else {
			bookResponseEntity = ResponseEntity.status(HttpStatus.OK).body(book);
			return bookResponseEntity;
		}
	}
		
	public ResponseEntity<?> getAllBooks() {
		List<Book> bookList = bookRepository.findAll();
		ResponseEntity<?> bookResponseEntity = null;
		if( bookList == null || !(bookList.size()>0) ) {
			bookResponseEntity = ResponseEntity.status(HttpStatus.NO_CONTENT).body(bookList);
			return bookResponseEntity;
		}
		else {
			bookResponseEntity = ResponseEntity.status(HttpStatus.OK).body(bookList);
			return bookResponseEntity;
		}	
	}
	
	public ResponseEntity<?> saveBook(Book book) {
		Book savedBook = bookRepository.findOne(book.getIsbn());
		if( savedBook == null ) {
			savedBook = bookRepository.save(book);
		}
		ResponseEntity<?> bookResponseEntity = null;
		if(savedBook == null) {
			bookResponseEntity = ResponseEntity.status(HttpStatus.BAD_REQUEST).body(savedBook);
			return bookResponseEntity;
		}
		else {
			bookResponseEntity = ResponseEntity.status(HttpStatus.CREATED).body(savedBook);
			return bookResponseEntity;
		}
	}
	
	public ResponseEntity<?> updateBook(Book book) {
		Book savedBook = bookRepository.findOne(book.getIsbn());
		if(savedBook != null) {
			savedBook=bookRepository.save(book);
		}
		ResponseEntity<?> bookResponseEntity = null;
		if(savedBook == null ) {
			bookResponseEntity = ResponseEntity.status(HttpStatus.BAD_REQUEST).body(savedBook);
			return bookResponseEntity;
		}
		else {
			bookResponseEntity = ResponseEntity.status(HttpStatus.ACCEPTED).body(savedBook);
			return bookResponseEntity;
		}
	}
	
	public ResponseEntity<?> deleteBook(Long isbn) {
		ResponseEntity<?> bookResponseEntity = null;
		bookRepository.delete(isbn);
		Book deletedBook = bookRepository.findOne(isbn);
		if( deletedBook != null) {
			bookResponseEntity = ResponseEntity.status(HttpStatus.NO_CONTENT).body(deletedBook);
			return bookResponseEntity;
		}
		else {
			bookResponseEntity = ResponseEntity.status(HttpStatus.OK).body(null);
			return bookResponseEntity;
		}
	}
}
