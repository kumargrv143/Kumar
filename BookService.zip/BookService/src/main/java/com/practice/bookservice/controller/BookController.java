package com.practice.bookservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.practice.bookservice.model.Book;
import com.practice.bookservice.service.BookService;

@RestController
@RequestMapping("/api")
public class BookController {
	
	@Autowired
	BookService bookService;

	@RequestMapping(value="/book/{isbn}", method = RequestMethod.GET ,produces= {MediaType.APPLICATION_JSON_VALUE},consumes= {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<?> getBook(@PathVariable("isbn") Long isbn) {
		ResponseEntity<?> response = bookService.getBook(isbn);
		return response;
	}
	
	@RequestMapping(value="/books", method = RequestMethod.GET ,produces= {MediaType.APPLICATION_JSON_VALUE},consumes= {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<?> getAllBooks() {
		ResponseEntity<?> response = bookService.getAllBooks();
		return response;
	}
	
	@RequestMapping(value="/book", method = RequestMethod.POST ,produces= {MediaType.APPLICATION_JSON_VALUE},consumes= {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<?> saveBook(@RequestBody Book book) {
		ResponseEntity<?> response = bookService.saveBook(book);
		return response;
	}
	
	@RequestMapping(value="/book", method = RequestMethod.PUT ,produces= {MediaType.APPLICATION_JSON_VALUE},consumes= {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<?> updateBook(@RequestBody Book book) {
		ResponseEntity<?> response = bookService.saveBook(book);
		return response;
	}
	
	@RequestMapping(value="/book/{isbn}", method = RequestMethod.DELETE ,produces= {MediaType.APPLICATION_JSON_VALUE},consumes= {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<?> deleteBook(@PathVariable("isbn") Long isbn) {
		ResponseEntity<?> response = bookService.deleteBook(isbn);
		return response;
	}
	
	
}
