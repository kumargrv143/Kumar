/**
 * Created by VISHAL on 11-05-2018.
 */

export class MyService{

  logStatus(status){
    console.log(status);
  }


}
